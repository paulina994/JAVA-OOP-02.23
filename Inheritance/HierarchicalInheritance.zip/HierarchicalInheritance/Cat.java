package Inheritance.LAB.HierarchicalInheritance;

public class Cat extends Animal {
    public void meow() {
        System.out.println("meow...");
    }

}

