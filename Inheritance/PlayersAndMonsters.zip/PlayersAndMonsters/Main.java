package Inheritance.EX.PlayersAndMonsters;

public class Main {
}
