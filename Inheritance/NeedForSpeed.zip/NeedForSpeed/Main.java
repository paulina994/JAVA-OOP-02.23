package Inheritance.EX.NeedForSpeed;

public class Main {
}
