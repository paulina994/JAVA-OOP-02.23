package Inheritance.EX.NeedForSpeed;

public class Vehicle {
    private static final double DOUBLE_FUEL_CONSUMPTION = 1.25;
    private double fuelConsumption; //литри разход за 1 км
    private double fuel; // налички литри гориво
    private int horsePower; //конски сили

    //constructor

    public Vehicle(double fuel, int horsePower) {
        this.fuel = fuel;
        this.horsePower = horsePower;
        this.fuelConsumption = DOUBLE_FUEL_CONSUMPTION;
    }

    public double getFuelConsumption() {
        return fuelConsumption;
    }

    public void setFuelConsumption(double fuelConsumption) {
        this.fuelConsumption = fuelConsumption;
      }

    public double getFuel() {
        return fuel;
    }

    public void setFuel(double fuel) {
        this.fuel = fuel;
    }

    public int getHorsePower() {
        return horsePower;
    }

    public void setHorsePower(int horsePower) {
        this.horsePower = horsePower;
    }

    public void drive(double kilometers) {
        double consumedFuel = kilometers * this.getFuelConsumption();
        if (this.getFuel() >= consumedFuel) {
            double leftFuel = this.getFuel() - consumedFuel;
            this.setFuel(leftFuel);
        }
    }
}
