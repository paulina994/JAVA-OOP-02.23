package spaceStation.models.planets;

import java.util.List;

public interface Planet {
    List<String> getItems();

    String getName();
}
