import org.junit.Test;

public class MyFirstTestClass {

    @Test
    public void testSumMethodWithPositiveNumbers(){


    }
    @Test
    public void testSumMethodWithNegativeNumbers(){


    }
}
