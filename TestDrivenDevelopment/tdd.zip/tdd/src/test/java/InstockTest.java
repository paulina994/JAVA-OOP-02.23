import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.cglib.transform.FieldVisitorTee;

import javax.sound.sampled.Port;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class InstockTest {

    private ProductStock stock;

    @Before
    public void setUp() {
        this.stock = new Instock();
    }

    //contains + add
    @Test
    public void testContainsAndAdd() {
        Product product = new Product("water", 1.20, 2);
        Assert.assertFalse(this.stock.contains(product));
        this.stock.add(product);
        Assert.assertTrue(this.stock.contains(product));
    }

    //count
    @Test
    public void testGetCount() {
        Assert.assertEquals(0, this.stock.getCount());
        fillStock();
        Assert.assertEquals(3, this.stock.getCount());
    }

    //find
    //1. correctly found product
    @Test
    public void testFindReturnCorrectProduct() {
        fillStock();

        Product foundProduct = this.stock.find(2);

        Assert.assertEquals(foundProduct.getLabel(), "cheese");
        Assert.assertEquals(foundProduct.getQuantity(), 5);

    }

    //2. index > дължина на списъка
    @Test(expected = IndexOutOfBoundsException.class)
    public void testFindThrowExceptionIndexGreater() {
        fillStock();

        this.stock.find(4);
    }

    //3. index < дължина на списъка
    @Test(expected = IndexOutOfBoundsException.class)
    public void testFindThrowExceptionIndexNegative() {
        fillStock();
        this.stock.find(-4);
    }

    @Test
    public void testChangeQuantitySuccessfullyUpdate() {
        //1.successfully change quantity
        fillStock();
        Product productBread = this.stock.find(1); // label: bread, price: 1.90 quantity: 3
        this.stock.changeQuantity("bread", 9);
        Assert.assertEquals(productBread.getQuantity(), 9);
    }

    //2. change on invalid product
    @Test(expected = IllegalArgumentException.class)
    public void testQuantityThrowInvalidProduct() {
        fillStock();
        this.stock.changeQuantity("wine", 8);
    }

    @Test
    public void testFindByLabelReturnCorrectProduct() {
        fillStock();
        Product expectedProduct = this.stock.find(0);
        Product returnProduct = this.stock.findByLabel("water");
        Assert.assertEquals(expectedProduct.getLabel(), returnProduct.getLabel());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFindByLabelThrowInvalidProduct() {
        fillStock();
        this.stock.findByLabel("potato");
    }

    @Test
    public void testFindFirstByAlphabeticalOrderCountProducts() {
        fillStock();
        Iterable<Product> iterable = this.stock.findFirstByAlphabeticalOrder(2);
        int countGetProducts = 0;
        for (Product product : iterable) {
            countGetProducts++;
        }
        Assert.assertEquals(2, countGetProducts);
    }

    @Test
    public void testFindFirstByAlphabeticalOrderCorrectSorted() {
        fillStock();
        List<String> expectedProductsLabels = new ArrayList<>(); // label на първоначалните продукти
        Product product1 = new Product("water", 1.20, 2);
        Product product2 = new Product("bread", 2.90, 3);
        Product product3 = new Product("cheese", 3.90, 5);
        this.stock.add(product1);
        expectedProductsLabels.add(product1.getLabel());
        this.stock.add(product2);
        expectedProductsLabels.add(product2.getLabel());
        this.stock.add(product3);
        expectedProductsLabels.add(product3.getLabel());

        expectedProductsLabels = expectedProductsLabels.
                stream()
                .sorted()
                .collect(Collectors.toList());

        Iterable<Product> iterable = this.stock.findFirstByAlphabeticalOrder(3);
        List<String> returnedProductLabels = new ArrayList<>();

        for (Product product : iterable) {
            returnedProductLabels.add(product.getLabel());
        }
        Assert.assertEquals(expectedProductsLabels, returnedProductLabels);
    }

    //2. невалиден брой
    @Test
    public void testFindFirstByAlphabeticalOrderCorrectSortedThrowInvalidCount() {
        fillStock();
        Iterable<Product> iterable = this.stock.findFirstByAlphabeticalOrder(5);
        int count = 0;
        for (Product product : iterable) {
            count++;
        }
        Assert.assertTrue(count == 0);
    }

    //1.правелен range
    @Test
    public void findAllInPriceRange() {
        fillStock();
        Iterable<Product> returnedProducts = this.stock.findAllInRange(1.10, 3.50);
        int count = 0;
        for (Product product : returnedProducts) {
            count++;
        }
        Assert.assertEquals(2, count);
    }

    //2.сортира продуктите
    @Test
    public void testFindAllInPriceRangeCorrectOrder() {
        fillStock();
        Iterable<Product> iterable = this.stock.findAllInRange(1.10, 2.95);
        List<Product> returnedProducts = new ArrayList<>();
        for (Product product : iterable) {
            returnedProducts.add(product);
        }
        Assert.assertEquals("bread", returnedProducts.get(0).getLabel());
        Assert.assertEquals("water", returnedProducts.get(1).getLabel());
    }

    //3,нямаме продукти в диапазона
    @Test
    public void testFindAllInPriceRangeNoneMatch() {
        fillStock();
        Iterable<Product> iterable = this.stock.findAllInRange(10, 20);
        Assert.assertFalse(iterable.iterator().hasNext());

    }

    @Test
    public void testFindAllByPriceCorrectProducts() {
        fillStock();
        Iterable<Product> iterable = this.stock.findAllByPrice(3.90);
        List<Product> returnedProducts = new ArrayList<>();
        for (Product product : iterable) {
            returnedProducts.add(product);
        }
        Assert.assertEquals(1, returnedProducts.size());
        Assert.assertEquals("cheese", returnedProducts.get(0).getLabel());
    }

    @Test
    public void testFindAllByPriceEmptyProducts() {
        fillStock();
        Iterable<Product> iterable = this.stock.findAllByPrice(15.20);
        Assert.assertFalse(iterable.iterator().hasNext());
    }

    @Test
    public void testFindAllByQuantityEmptyProducts() {
        fillStock();
        Iterable<Product> iterable = this.stock.findAllByQuantity(10);
        Assert.assertFalse(iterable.iterator().hasNext());
    }

    @Test
    public void testFindAllByQuantityCorrectProducts() {
        fillStock();
        Iterable<Product> iterable = this.stock.findAllByQuantity(3);
        List<Product> returnedProducts = new ArrayList<>();
        for (Product product : iterable) {
            returnedProducts.add(product);
        }
        Assert.assertEquals(1, returnedProducts.size());
        Assert.assertEquals("bread", returnedProducts.get(0).getLabel());
    }

    @Test
    public void testIterator() {
        fillStock();

        List<String> expectedProductsLabels = new ArrayList<>(); // label на първоначалните продукти
        Product product1 = new Product("water", 1.20, 2);
        Product product2 = new Product("bread", 2.90, 3);
        Product product3 = new Product("cheese", 3.90, 5);
        expectedProductsLabels.add(product1.getLabel());
        expectedProductsLabels.add(product2.getLabel());
        expectedProductsLabels.add(product3.getLabel());
        Iterator<Product> iterator = this.stock.iterator();
        List<Product> returnedProducts = new ArrayList<>();
        while (iterator.hasNext()) {
            returnedProducts.add(iterator.next());

        }
        List<String> returnedProductsLabels = new ArrayList<>();
        for (Product product : returnedProducts) {
            returnedProductsLabels.add(product.getLabel());
        }
        Assert.assertEquals(returnedProductsLabels, expectedProductsLabels);
    }

    private void fillStock() {
        Product product = new Product("water", 1.20, 2);
        Product product1 = new Product("bread", 2.90, 3);
        Product product2 = new Product("cheese", 3.90, 5);
        this.stock.add(product);
        this.stock.add(product1);
        this.stock.add(product2);

    }
}
