package InterfacesAndAbstraction.EX.CollectionHierarchy;

public interface MyList extends AddRemovable{
    int getUsed();
}
