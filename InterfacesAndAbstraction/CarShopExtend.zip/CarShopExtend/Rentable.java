package InterfacesAndAbstraction.LAB.CarShopExtend;

public interface Rentable extends Car {
    Integer getMinRentDay();
    Double getPricePerDay();

}
