package InterfacesAndAbstraction.EX.MultipleImplementation;

public interface Birthable {
    String getBirthDate();
}
