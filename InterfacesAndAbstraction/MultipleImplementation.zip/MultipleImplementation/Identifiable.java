package InterfacesAndAbstraction.EX.MultipleImplementation;

public  interface Identifiable {
    String getId();
}
