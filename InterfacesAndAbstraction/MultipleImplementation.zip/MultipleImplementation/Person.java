package InterfacesAndAbstraction.EX.MultipleImplementation;

public interface Person {
    public String getName();
    int getAge();
}
