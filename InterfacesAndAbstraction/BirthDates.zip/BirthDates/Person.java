package InterfacesAndAbstraction.EX.BirthDates;

public interface Person {
    public String getName();
    int getAge();
}
