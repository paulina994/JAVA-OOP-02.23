package InterfacesAndAbstraction.EX.BirthDates;

public  interface Identifiable {
    String getId();
}
