package InterfacesAndAbstraction.EX.BirthDates;

public interface Birthable {
    String getBirthDate();
}
