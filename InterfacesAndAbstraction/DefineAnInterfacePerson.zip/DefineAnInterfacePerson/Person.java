package InterfacesAndAbstraction.EX.DefineAnInterfacePerson;

public interface Person {
    public String getName();
    int getAge();
}
