package InterfacesAndAbstraction.EX.FootShortage;

public class Rebel implements Buyer,Person {
    private String name;
    private int age;
    private String group;
    private int food;

    @Override
    public void buyFood() {
        food += 5;
    }

    public Rebel(String name, int age, String group) {
        this.name = name;
        this.age = age;
        this.group = group;
    }

    @Override
    public int getFood() {
        return food;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getAge() {
        return 0;
    }
}
