package InterfacesAndAbstraction.EX.FootShortage;

public interface Buyer {
    void buyFood();
    int getFood();
}
