package InterfacesAndAbstraction.EX.FootShortage;

public  interface Identifiable {
    String getId();
}
