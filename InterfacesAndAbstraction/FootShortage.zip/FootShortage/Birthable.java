package InterfacesAndAbstraction.EX.FootShortage;

public interface Birthable {
    String getBirthDate();
}
