package InterfacesAndAbstraction.EX.FootShortage;

public interface Person {
    public String getName();
    int getAge();
}
