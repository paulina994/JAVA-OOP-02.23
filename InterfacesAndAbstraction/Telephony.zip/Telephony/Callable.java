package InterfacesAndAbstraction.EX.Telephony;

public interface Callable {
    String call();
}
