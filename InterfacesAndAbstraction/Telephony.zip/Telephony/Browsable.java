package InterfacesAndAbstraction.EX.Telephony;

public interface Browsable {
    String browse();
}
