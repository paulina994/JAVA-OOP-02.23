package Polymorphism.LAB.MathOperation;

public class Main {
    public static void main(String[] args) {

        MathOperation.add(1,2);

        
    }
}
