package Polymorphism.LAB.Animal;

public class Cat extends Animal{

    public Cat(String name,String favouriteFood) {
        super.setName(name);
        super.setFavouriteFood(favouriteFood);
    }

    @Override
    public String explainSelf() {
        return String.format("I am %s and my favourite food is %s%nDJAAF", super.getName(),super.getFavouriteFood());
    }
}
